Quick start:

```
$ npm install
$ npm run dev 
```
site exapmle : https://notes-app-uwais.netlify.app/
